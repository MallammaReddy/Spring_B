/*package net.guides.springboot2.springboot2jpacrudexample;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.net.URI;
import java.net.URISyntaxException;

import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import net.guides.springboot2.springboot2jpacrudexample.model.Employee;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class EmployeeControllerIntegrationTest {
	
	@Autowired
	public RestTemplate restTemplate;

	@LocalServerPort
	private int port;
	
	 //Timeout value in milliseconds
    int timeout = 10_000;
     
     
    @Before
    public void setUp()
    {
        //restTemplate = new RestTemplate(getClientHttpRequestFactory());
    }
     

	private String getRootUrl() {
		return "http://localhost:" + port;
	}

	@Test
	public void contextLoads() {

	}

	@Test
	public void testGetAllEmployees() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/employees",
				HttpMethod.GET, entity, String.class);
		
		assertNotNull(response.getBody());
	}

	@Test
	public void testGetEmployeeById() {
		Employee employee = restTemplate.getForObject(getRootUrl() + "/employees/1", Employee.class);
		System.out.println(employee.getFirstName());
		assertNotNull(employee);
	}

	@Test
	public void testCreateEmployee() {
		Employee employee = new Employee();
		employee.setEmailId("admin@gmail.com");
		employee.setFirstName("admin");
		employee.setLastName("admin");

		ResponseEntity<Employee> postResponse = restTemplate.postForEntity(getRootUrl() + "/employees", employee, Employee.class);
		assertNotNull(postResponse);
		assertNotNull(postResponse.getBody());
	}

	@Test
	public void testUpdateEmployee() {
		int id = 1;
		Employee employee = restTemplate.getForObject(getRootUrl() + "/employees/" + id, Employee.class);
		employee.setFirstName("admin1");
		employee.setLastName("admin2");

		restTemplate.put(getRootUrl() + "/employees/" + id, employee);

		Employee updatedEmployee = restTemplate.getForObject(getRootUrl() + "/employees/" + id, Employee.class);
		assertNotNull(updatedEmployee);
	}

	@Test
	public void testDeleteEmployee() {
		int id = 2;
		Employee employee = restTemplate.getForObject(getRootUrl() + "/employees/" + id, Employee.class);
		assertNotNull(employee);

		restTemplate.delete(getRootUrl() + "/employees/" + id);

		try {
			employee = restTemplate.getForObject(getRootUrl() + "/employees/" + id, Employee.class);
		} catch (final HttpClientErrorException e) {
			assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);
		}
	}
	
	  private HttpComponentsClientHttpRequestFactory getClientHttpRequestFactory()
	    {
	        HttpComponentsClientHttpRequestFactory clientHttpRequestFactory
	                          = new HttpComponentsClientHttpRequestFactory();
	         
	        clientHttpRequestFactory.setHttpClient(httpClient());
	              
	        return clientHttpRequestFactory;
	    }
	
	
	 private HttpClient httpClient()
	    {
	        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
	 
	        credentialsProvider.setCredentials(AuthScope.ANY,
	                        new UsernamePasswordCredentials("admin", "password"));
	 
	        HttpClient client = HttpClientBuilder
	                                .create()
	                                .setDefaultCredentialsProvider(credentialsProvider)
	                                .build();
	        return client;
	    }
	 
	 @Test
	    public void testGetEmployeeList_success() throws URISyntaxException
	    {
		   RestTemplate restTemplate = new RestTemplate();
	        final String baseUrl = "http://localhost:"+port+"/employees/1";
	        URI uri = new URI(baseUrl);
	 
	        ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
	        System.out.println("testing testGetEmployeeList_success"+result.getStatusCodeValue());
	         
	        //Verify request succeed
	        Assert.assertEquals(200, result.getStatusCodeValue());
	        //Assert.assertEquals(true, result.getBody().contains("employeeList"));
	        
	       
	    }
	 
}
*/