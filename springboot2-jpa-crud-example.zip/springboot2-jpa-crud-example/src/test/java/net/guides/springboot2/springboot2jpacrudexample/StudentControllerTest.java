package net.guides.springboot2.springboot2jpacrudexample;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import net.guides.springboot2.springboot2jpacrudexample.model.Student;
import net.guides.springboot2.springboot2jpacrudexample.repository.StudentRepository;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class})
public class StudentControllerTest {
	
	@Autowired
	StudentRepository studentRepository;
	
	@Test
	@Transactional
	public void testStudentData() {
		
		Student s=new Student(1003,"Hasareddy","AZWERTO");

		Student s1=new Student(1004,"mallamma","nnmpuiop");
		studentRepository.save(s);
		studentRepository.save(s1);
		
		Optional<Student> st=studentRepository.findByName("Hasareddy");
		
		List<Student> sts=studentRepository.findAll();
		
		//assertEquals("1003", st.getId());
		//assertEquals(true,st.isPresent());
		assertEquals(2,sts.size());
		
	}
	

}
