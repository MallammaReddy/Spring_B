package net.guides.springboot2.springboot2jpacrudexample.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.guides.springboot2.springboot2jpacrudexample.model.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student,Long> {
	public Optional<Student> findByName(String name);


}
