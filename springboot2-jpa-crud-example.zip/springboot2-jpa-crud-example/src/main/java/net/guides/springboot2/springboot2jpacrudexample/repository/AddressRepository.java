package net.guides.springboot2.springboot2jpacrudexample.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.guides.springboot2.springboot2jpacrudexample.model.Address;
import net.guides.springboot2.springboot2jpacrudexample.model.Student;

@Repository
public interface AddressRepository extends JpaRepository<Address,Long> {
	public Optional<Address> findByStreet(String street);
	public Optional<Address> findById(String id);


}
