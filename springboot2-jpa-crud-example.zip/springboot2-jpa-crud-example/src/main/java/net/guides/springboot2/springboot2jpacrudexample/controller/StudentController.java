package net.guides.springboot2.springboot2jpacrudexample.controller;

import java.net.URI;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import net.guides.springboot2.springboot2jpacrudexample.model.Address;
import net.guides.springboot2.springboot2jpacrudexample.model.Student;
import net.guides.springboot2.springboot2jpacrudexample.repository.AddressRepository;
import net.guides.springboot2.springboot2jpacrudexample.repository.StudentRepository;

@RestController

public class StudentController {
	
	@Autowired
	StudentRepository studentRepository;
	
	@Autowired
	AddressRepository addressRepository;
	
	@GetMapping("/student/all")
	public List<Student> getStudentDetails() {
		System.out.println("getStudentDetails");
		List<Student> st=new ArrayList<>();
		//return studentRepository.findAll();
		studentRepository.findAll().forEach(st::add);
		return st;
		
	}


	@GetMapping("/address/all")
	public List<Address> getAddressDetails() {
		System.out.println("getAddressDetails");
		return addressRepository.findAll();
		
	}

	
	@GetMapping("/student/{id}")
	public Optional<Student> getStudentById(@PathVariable long id) {
		System.out.println("getStudentById");
		return studentRepository.findById(id);
		
	}
	
	@PutMapping("/student/save")
	public ResponseEntity<Object> saveStudents(@RequestBody Student s) {
		//Student s=new Student(1003,"reddy","1A20QWERT");
		Address a=new Address();
		Set<Address> adr=new HashSet<Address>();
		a.setId(1);
       a.setStreet("SM");
		adr.add(a);
		//s.setAddress(adr);
		//addressRepository.save(a);
		Student saveStudents=studentRepository.save(s);
		addressRepository.save(a);
		
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(saveStudents.getId()).toUri();

		return ResponseEntity.created(location).build();
		
	}
	
	@PostMapping("/student/update/{id}")
	public ResponseEntity<Optional<Student>> updateStudents(@RequestBody Student s,@PathVariable long id) throws Exception {
		//Student s=new Student(1003,"reddy","1A20QWERT");
		Optional<Student>  student=studentRepository.findById(id);
		Optional<Student>  updstudent;
		if(!student.isPresent()) {
			//throw new Exception("Student not fund");
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}else
		{
		
		student.get().setPassportNumber("gggggggg");
			studentRepository.save(student.get());
			updstudent=studentRepository.findById(student.get().getId());
		}
		
		return ResponseEntity.ok().body(updstudent);
	}
	@GetMapping("student/date")
	public Date getDate() {
		System.out.println("getDate");
		return new Date(0);
		
	}
	
	@DeleteMapping("student/{id}")
	public void deleteName(@PathVariable long id) {
		System.out.println("deleteName");
		studentRepository.deleteById(id);
		
	}
}
