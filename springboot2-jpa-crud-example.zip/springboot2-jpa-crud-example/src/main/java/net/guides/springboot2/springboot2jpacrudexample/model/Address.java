package net.guides.springboot2.springboot2jpacrudexample.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.ManyToAny;

@Entity
@Table(uniqueConstraints = {
		@UniqueConstraint(columnNames = "id")})
public class Address implements java.io.Serializable {
	
@Id
private long id;

private String street;

//@ManyToMany(mappedBy="address")
//@JoinColumn(name="id")

//@OneToOne
//@PrimaryKeyJoinColumn

@ManyToOne(fetch = FetchType.LAZY,targetEntity=Student.class)
@PrimaryKeyJoinColumn
private Student stud;





public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getStreet() {
	return street;
}

public void setStreet(String street) {
	this.street = street;
}

public Student getStud() {
	return stud;
}

public void setStud(Student stud) {
	this.stud = stud;
}




}
