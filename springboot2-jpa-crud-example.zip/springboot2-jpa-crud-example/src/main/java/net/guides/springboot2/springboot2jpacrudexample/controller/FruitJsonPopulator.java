package net.guides.springboot2.springboot2jpacrudexample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.data.repository.init.Jackson2RepositoryPopulatorFactoryBean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import net.guides.springboot2.springboot2jpacrudexample.repository.FruitRepository;

@RestController
public class FruitJsonPopulator {
	
	@Autowired
	FruitRepository fruitRepository;
	
	@GetMapping("/fruits")
	public Jackson2RepositoryPopulatorFactoryBean getJson() throws Exception {
		JpaPopulators JpaPopulators = new JpaPopulators();
		return JpaPopulators.getRespositoryPopulator();
		
		
	}

}
